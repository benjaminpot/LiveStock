# VR 誇張動作羊 V1 規劃

本方案供確認後實作；本輪只修正 walk 命名、檢查原始資料，沒有改動骨架。

## 已確認的現況

- 專案 Animation Rigging 版本為 1.4.1，Unity 為 6000.3.25f1。
- 原始資料只有 head、L-hand、R-hand 的 TrackingSpace-relative 位置與旋轉。
- 沒有 XR tracking validity、身體／後腳追蹤、錄製時羊的尺寸與姿勢、完整映射設定。
- 舊 offset 相容轉換保留了來源軌跡，但仍把第一幀對齊目前 Rig rest pose；因此不是當時全身姿勢的精確重建。
- 目前播放器只控制頭部 Target 與兩個前腳 Target，沒有主動控制軀幹、後腳或腳掌接地。
- SK_Sheep_VRMotion.prefab 左前腳 TwoBoneIK：Root=Rump_L_joint（後腿），Mid=KneeFront_L_joint（前腿），跨骨骼分支。
- 右前腳 TwoBoneIK：Root=RumpFront_R_joint，Mid=KneeFront_R_joint，Tip=ToesFront_R_joint；跨過 HipFront 與 AnkleFront，不是乾淨的兩段骨骼鏈。
- 左右前腳都未設定 Hint，Target Rotation Weight=1；手把旋轉會全額傳給腳掌。
- Multi-Aim 以目標位置計算注視方向，不能直接完整傳遞 HMD 的 pitch/yaw/roll；目前程式也沒有以頭盔旋轉驅動 headTarget.rotation。

## 原始錄製檢查

`Tools/audit_motion_recordings.py` 可重跑檢查。以下數值來自二進位資料，而非只讀 metadata。

| 動作 | 幀數 | 首末幀時間差 | 掉樣數 | 狀態 |
|---|---:|---:|---:|---|
| walk（原 test1） | 1229 | 20.5167 s | 3 | 完整、時間遞增、無尾端截斷 |
| idle | 1445 | 24.0667 s | 0 | 完整 |
| eat | 1046 | 17.4167 s | 0 | 完整 |

walk 頭部垂直範圍只有 1.13 cm；左／右手前後範圍分別約 30.82／17.48 cm。
三条軌跡所有幀的 active flag 都為 true，位置／旋轉都有大量變化。
這證明檔案有保存可變 Pose；active flag 不是 XR 裝置有效追蹤證明，也不能單靠這些數值證明動作必定是自然步行。

## 建議架構

原始錄製 → 校正與濾波 → 動作特徵 → 每隻羊的表演設定 → 控制物件 → Rig 層 → 骨架。

1. 原始層：保留現有錄製，避免烘入任何羊專屬設定。
2. 校正層：獨立儲存 neutral pose、來源朝向、動作片段起止點；不再把每段動作的第一幀一律視為中立姿勢。
3. 特徵層：取得頭部點頭／轉頭／歪頭、頭高度、左右手擺動、共同前傾、動作速度、步態相位。
4. 表演層：每個動作一份可拖曳的設定資產，控制幅度曲線、限幅、濾波、身體連動、腳掌接地與循環接縫。
5. Rig 層：明確定義執行顺序與骨頭擁有權，避免同一骨頭被 Animator、腳本與不同 constraints 重複覆蓋。

## 骨架控制建議

| 區域 | V1 控制方式 | 用途 |
|---|---|---|
| 頭 | 校正後的 HMD 旋轉 → HeadOrientation 控制物件 → Multi-Rotation | 完整表現点頭、轉頭、歪頭 |
| 頸 | Neck_M / Neck1 的独立旋轉控制物件與 Multi-Rotation | 分配轉頭與低頭幅度，避免頭部像孤立球體 |
| 軀幹 | Pelvis / Spine1 / Spine2 控制物件；Rotation 與必要的 Position constraint | 前傾、彈跳、重心左右轉移 |
| 四肢 | 每腳 TwoBoneIK + Hint | 明確兩段鏈、固定膝彎方向 |
| 腳掌／腳趾 | 接地法線決定脚掌方向，腳趾單獨控制 | 防止手把翻腕把腳掌轉翻 |
| 耳／尾 | 小幅延遲跟隨（後續再加） | 增強卡通表現，V1 先低優先 |

Multi-Aim 可保留為未來看玩家／草地的額外行為，本輪建議讓 HeadOrientation 作為頭部主控制。
頸部與頭部要先算累積世界朝向，再求各節父子相對旋轉，不能把相同 HMD 旋轉全額疊到每一節。

四腳 IK 候選鏈：前腳 HipFront → KneeFront → AnkleFront；後腳 Hip → Knee → Ankle。
此候選須檢查每段实际父子鏈與網格變形後確定；Rump 用於肩胛／髖連動，Toes 用於腳趾，而非先把它們接進 TwoBoneIK。

Rig 建議順序：Body → Neck/Head → Legs → Feet/Secondary。
Body 改變骨盆與肩部後才解腿部 IK；所有 Target 放於不受被控制骨骼回饋的 Controls 階層。
純 VR 表演模式使用固定中立基礎姿勢，Animator 保持啟用以支援 Animation Rigging，底層不播放 idle/eat/walk clip。
另提供混合模式作可選用途；頭部与軀幹控制需根據模式切換避免雙重驅動。

## 三種動作的 V1 行為

- idle：保留原始轉頭／歪頭節奏；加入小幅肩部與胸腔跟隨。四腳保持接地，忽略微小手部抖動。
- eat：HMD 低頭角與高度下降一起驅動頸部與胸部前傾；前腳撑地、後腳調整重心。不要把 HMD 下降 77.73 cm 全額指定給羊頭位置。
- walk：保留錄製的左右手擺動節奏與頭部擺動；取穩定循環片段。四脚接觸／擺動相位由手部訊號和動作設定推導，後脚與軀幹聯動屬於程序生成，不是錄得的後腿追蹤。
- walk V1 先做原地步態；路徑移動交給 NPC Root 的導航／移動系統。

誇張感優先放在頭／頸／胸的角度、抬腳高度、擺動幅度和身體起伏。
建议先試 1.3–1.8 倍旋轉增益，再依每個動作調整；这是美術調參起點，不是已驗證的最佳值。
腳部 displacement 以腿長正規化，限制 IK 可達範圍；超出時先讓胸／骨盆補償，避免直腿拉滿。
不直接縮放骨頭製造 squash/stretch，避免網格與 IK 長度互相干擾。

## 未來錄製方法

繼續以 HMD／左右手原始 Pose 為主資料；另可選錄製最終控制物件作 debug。
metadata 增加：tracking-valid flag、TrackingSpace scale、neutral calibration、表演設定版本、羊 Rig／尺寸識別、sample gaps。
錄製流程增加中立校正倒數；每個動作單独錄製。Walk 建議先穩定數秒，再錄多個清晰交替週期。
現有資料缺少這些資訊，V1 必須讓使用者選校正幀／片段與微調比例，而不宣稱精準復原當時全身姿勢。

## 實作順序與驗收

1. 建立新 V1 Prefab 與獨立表演設定資產，先修骨骼鏈、Hint 和控制物件基準姿勢。
2. 頭頸旋轉與胸腔聯動先完成，用 idle/eat 做調參；確認 yaw/pitch/roll 與前傾都清楚。
3. 四腳 IK／接地、walk 相位與後腳程序聯動，再處理平滑循環。
4. 新播放器接現有錄製資產；保留直接拖入檔案、關閉 base animation、速度與 loop 控制。
5. 未來錄製器增加校正及追蹤有效性欄位；无需重錄現有三份資料才能開始 V1。

驗收：同片段在 Root 朝向 0/90/180 度、兩種模型尺寸下產生一致局部动作；歪頭有 roll；低頭時頸胸一起動；四腳有交替／接地；關閉底層 clip 仍有清楚步態；單幀拖曳、暫停及重播結果一致；loop 接縫無明顯跳動。

## 官方文件

- 提供的 1.0 文件：https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.0/manual/index.html
- 本專案 1.4 workflow：https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.4/manual/RiggingWorkflow.html
- Multi-Rotation：https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.4/manual/constraints/MultiRotationConstraint.html
- Multi-Aim：https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.4/manual/constraints/MultiAimConstraint.html
- Two Bone IK：https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.4/manual/constraints/TwoBoneIKConstraint.html
