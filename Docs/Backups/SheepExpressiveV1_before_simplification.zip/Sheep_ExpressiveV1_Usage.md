# Expressive Sheep V1 使用說明

## 新增物件

- Prefab：`Assets/_Project/model/SK_Sheep_ExpressiveV1.prefab`
- 場景比較物件：`SK_Sheep_ExpressiveV1`，位於原播放羊旁邊。
- 表演設定：`Assets/_Project/Generated/SheepExpressiveV1/Idle.asset`、`Eat.asset`、`Walk.asset`。
- 固定骨架基準：同資料夾下的 `NeutralPose.anim`，只提供固定姿勢，不產生步態動作。
- 播放器：`SheepExpressivePlayer`；現有 VR 羊與舊播放器仍是獨立物件。

## 播放

1. 進入 Play Mode，選取新羊的 Sheep Expressive Player。
2. 使用 Play idle / eat / walk 按鈕。
3. Pause 後可以用 Time 滑桿逐幀／逐時間檢查；拖動滑桿會保持暫停。
4. Stop / Restore 回到骨架基準姿勢。
5. Default Motion 決定自動播放的動作，預設 idle。

自訂錄製：拖 MotionRecordingAsset 到 Custom Recording，或拖 metadata.json / frames.bytes
到 Custom Metadata / Custom Binary Frames，再指定 Custom Profile。
Custom Recording 優先於兩個原始檔案欄位；按 Play Dragged Recording 即可播放。
Use Custom On Start 配合 Play On Start 可以啟動即播放自訂資料。
V1 需要 head / L-hand / R-hand 三條 TrackingSpace-relative position + rotation 軌跡。

Use Base Animation 預設關閉，Animator 仍保留以執行 Animation Rigging。
啟用後會使用 Base Animator Controller 的同名 state；這是可選混合模式。
不同表演與 Clip 的混合仍需美術調參，純錄製表演是 V1 的主要模式。

## 如何調誇張程度

- Rotation Gain：三軸旋轉放大倍率。
- Angle Limits：限制頭部的旋轉量，降低大角度造成的翻轉或網格穿插。
- Neck Share：總旋轉分配給頸部的比例；頭部仍達到完整目標朝向。
- Body Follow：軀幹跟隨頭部的程度。
- Crouch Fraction：eat 低頭時骨盆下降比例。
- Stride / Lift Fraction：walk 的步幅與抬腳高度，依腿長縮放。
- Bounce Fraction：walk 身體起伏幅度。
- Hand Influence：原始手部前後移動對步幅的修飾。
- Smoothing Seconds：頭部旋轉平滑時間；Seek 直接取指定時間的姿勢。
- Start / End Time：選擇播放片段；End=0 使用錄製最後一幀。
- Loop Blend Seconds：在循環末尾混合回片段起點。

Neutral Recording 預設 Idle.asset，Profile 的 Neutral Time 決定校正時間。
吃草與走路共用這個獨立的中立來源，而非把各段第一幀都視為中立。
Source To Sheep Euler 用於調整來源座標到羊本體座標的軸向。

## 骨架與播放方式

- 頭頸使用 Multi-Rotation，支援點頭、轉頭、歪頭。
- Body → Head/Neck → Four Legs 三層依序解算。
- 四腳皆為 Hip → Knee → Ankle 的直接父子鏈，每腳有獨立 Hint。
- 腳掌方向來自模型基準姿勢，不會隨手把翻腕翻轉。
- Idle/Eat 腳掌維持基準站姿目標；Walk 用手部訊號估計節奏，產生對角交替四腳。
- 原地 walk 的支撐腳沿地面前後走動，屬於原地步態；尚未做世界空間鎖腳或地形 Raycast。
- 腳目標依腿長限制可達範圍，部分姿勢會稍微離開基準地面以避免腿完全伸直。
- 每次播放在 LateUpdate 更新控制物件，再手動 Evaluate Rig graph，避免 Target 更新比 IK 晚一幀。
- 中立姿勢 Clip 先寫入動畫串流，再解算 Body／HeadNeck／FourLegs；Hint 含外側偏移以避免反向共線。
- 暫停與 Seek 可重現同一時間的姿勢；Root 可以轉向，支援正值等比縮放。

後腳與身體步態屬於程序生成，原始檔並未記錄後腳／身體追蹤。
尾巴、耳朵延遲動畫、崎嶇地形接地、世界空間腳掌鎖定留給下一版。
目前模型分段羊毛在大角度彎曲時可能露出接縫；可先降低 Body Follow／Angle Limits，再考慮調整模型蒙皮。

## 重建工具

- Tools > LiveStock > Create Expressive Sheep V1：重建新 Prefab，保留已存在 Profile 的調參。
- Tools > LiveStock > Add Expressive Sheep V1 To Scene：目前場景沒有 V1 時新增比較羊。
- 場景新增以 Undo 記錄並保持待儲存；確認位置後自行儲存場景。

## 本次驗證

Unity Runtime／Editor 腳本編譯成功。三份錄製各取樣 61 個姿勢，最大腳掌到 Target 距離：
Idle 0.1374 mm、Eat 0.0086 mm、Walk 0.0139 mm（本次場景尺寸）。
0／90／180 度朝向與 1／1.5 倍等比尺寸的局部腳位最大差約 0.012 mm。
暫停後跳到其他時間再回到同一時間，腳掌位置差為 0；拖入 Walk.asset 能播放。
Walk 從錄製左右手交替過零節奏估計得到約 0.8286 次／秒。
這些是解算穩定性檢查，動作美術表現仍可用 Profile 調整。
