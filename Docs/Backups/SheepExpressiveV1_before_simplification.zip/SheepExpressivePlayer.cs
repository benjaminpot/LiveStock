using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.Animations;
using UnityEngine.Experimental.Animations;
using UnityEngine.Playables;

namespace LiveStock.MotionRecording
{
    [Serializable]
    public sealed class SheepExpressiveMotion
    {
        public string name;
        public MotionRecordingAsset recording;
        public SheepExpressiveProfile profile;
    }

    [Serializable]
    public sealed class SheepRotationControl
    {
        public Transform bone;
        public Transform control;
        [Range(0, 1)] public float headShare;
        [Range(0, 1)] public float bodyShare = 1;
        public bool finalHead;
        public Quaternion restInRoot;
    }

    [Serializable]
    public sealed class SheepLegControl
    {
        public Transform hip;
        public Transform knee;
        public Transform ankle;
        public Transform target;
        public Transform hint;
        public Vector3 restPosition;
        public Quaternion restRotation;
        public Vector3 hintPosition;
        public float length;
        public bool front;
        public bool left;
    }

    // Targets are written before one manual Rig evaluation. No controller clip is required.
    [DefaultExecutionOrder(1000)]
    [RequireComponent(typeof(Animator), typeof(RigBuilder))]
    public sealed class SheepExpressivePlayer : MonoBehaviour
    {
        public Animator animator;
        public RigBuilder rigBuilder;
        public AnimationClip neutralPoseClip;
        public Transform pelvis;
        public Transform pelvisPositionControl;
        public SheepRotationControl[] rotations;
        public SheepLegControl[] legs;
        public MotionRecordingAsset neutralRecording;
        public SheepExpressiveMotion[] motions;
        [Header("Playback")]
        public string defaultMotion = "idle";
        public bool playOnStart = true;
        public bool loop = true;
        [Min(0.01f)] public float playbackSpeed = 1;
        [Tooltip("Optional clip layer beneath the procedural rig; disabled for pure recorded expression.")]
        public bool useBaseAnimation;
        public RuntimeAnimatorController baseAnimatorController;
        [Header("Drag-in Recording")]
        public MotionRecordingAsset customRecording;
        public TextAsset customMetadata;
        public TextAsset customBinaryFrames;
        public SheepExpressiveProfile customProfile;
        public bool useCustomOnStart;
        [Header("Coordinates")]
        public Vector3 sourceToSheepEuler;

        public bool IsPlaying { get; private set; }
        public string CurrentMotion { get; private set; }
        public float PlaybackTime { get; private set; }
        public float Duration => _end - _start;
        public float GaitFrequency => _frequency;
        public string GaitSource { get; private set; }

        private List<TransformMotionFrame> _frames;
        private TransformMotionMetadata _metadata;
        private SheepExpressiveProfile _profile;
        private RecordedTransformSample[] _neutral;
        private int _head, _left, _right;
        private float _start, _end, _frequency;
        private Vector3 _filteredAngles;
        private Vector3 _pelvisRest;
        private Transform[] _bones;
        private Vector3[] _positions;
        private Quaternion[] _rotations;
        private readonly Dictionary<Transform, int> _boneIndices = new Dictionary<Transform, int>();
        private readonly Dictionary<Transform, Quaternion> _desiredRotations = new Dictionary<Transform, Quaternion>();
        private bool _lastBaseAnimation;
        private AnimationPlayableOutput _neutralOutput;

        private void Awake()
        {
            _bones = pelvis.parent.GetComponentsInChildren<Transform>(true);
            _positions = new Vector3[_bones.Length];
            _rotations = new Quaternion[_bones.Length];
            for (int i = 0; i < _bones.Length; i++)
            {
                _boneIndices[_bones[i]] = i;
                _positions[i] = _bones[i].localPosition;
                _rotations[i] = _bones[i].localRotation;
            }
            _pelvisRest = transform.InverseTransformPoint(pelvis.position);
        }

        private void Start()
        {
            PrepareGraph();
            if (playOnStart)
            {
                if (useCustomOnStart) PlayCustom(); else Play(defaultMotion);
            }
        }

        private void PrepareGraph()
        {
            var desiredController = useBaseAnimation ? baseAnimatorController : null;
            if (animator.runtimeAnimatorController != desiredController)
            {
                rigBuilder.Clear();
                animator.runtimeAnimatorController = desiredController;
            }
            if (!rigBuilder.graph.IsValid() && !rigBuilder.Build())
                throw new InvalidOperationException("Expressive sheep RigBuilder could not build.");
            if (!_neutralOutput.IsOutputValid())
            {
                if (neutralPoseClip == null) throw new InvalidOperationException("V1 neutral pose clip is required.");
                var pose = AnimationClipPlayable.Create(rigBuilder.graph, neutralPoseClip);
                _neutralOutput = AnimationPlayableOutput.Create(rigBuilder.graph,"V1 Neutral Pose",animator);
                _neutralOutput.SetSourcePlayable(pose);
                _neutralOutput.SetSortingOrder(0);
            }
            _neutralOutput.SetWeight(useBaseAnimation ? 0 : 1);
            rigBuilder.graph.SetTimeUpdateMode(DirectorUpdateMode.Manual);
            _lastBaseAnimation = useBaseAnimation;
        }

        private void LateUpdate()
        {
            if (_frames == null) return;
            if (_lastBaseAnimation != useBaseAnimation) PrepareGraph();
            animator.speed = useBaseAnimation && IsPlaying ? playbackSpeed : 0;
            if (IsPlaying)
            {
                PlaybackTime += Time.deltaTime * Mathf.Max(0.01f, playbackSpeed);
                if (PlaybackTime > Duration)
                {
                    if (loop && Duration > 0) PlaybackTime %= Duration;
                    else { PlaybackTime = Duration; IsPlaying = false; }
                }
            }
            ApplyPose(IsPlaying ? Time.deltaTime : 0);
        }

        public bool Play(string motionName)
        {
            if (motions != null)
                foreach (var entry in motions)
                    if (string.Equals(entry.name, motionName, StringComparison.OrdinalIgnoreCase))
                        return Load(entry.recording, entry.profile);
            Debug.LogWarning("Unknown expressive sheep motion: " + motionName, this);
            return false;
        }

        public bool PlayCustom()
        {
            if (customRecording != null) return Load(customRecording, customProfile);
            try
            {
                if (customMetadata == null || customBinaryFrames == null)
                    throw new InvalidOperationException("Drag a recording asset or both metadata.json and frames.bytes.");
                var frames = TransformMotionBinaryFormat.ReadAllFrames(customMetadata.text, customBinaryFrames.bytes, out var metadata);
                return Begin(frames, metadata, customProfile);
            }
            catch (Exception error) { Debug.LogException(error, this); return false; }
        }

        private bool Load(MotionRecordingAsset asset, SheepExpressiveProfile profile)
        {
            try
            {
                if (asset == null) throw new InvalidOperationException("A recording is required.");
                var frames = asset.LoadFrames(out var metadata);
                return Begin(frames, metadata, profile);
            }
            catch (Exception error) { Debug.LogException(error, this); return false; }
        }

        private bool Begin(List<TransformMotionFrame> frames, TransformMotionMetadata metadata, SheepExpressiveProfile profile)
        {
            if (profile == null || neutralRecording == null || frames.Count < 2)
                throw new InvalidOperationException("Assign an expressive profile, a neutral recording and at least two frames.");
            int head = Track(metadata, "head"), left = Track(metadata, "L-hand"), right = Track(metadata, "R-hand");
            var neutralFrames = neutralRecording.LoadFrames(out var neutralMetadata);
            var neutral = new[] {
                Sample(neutralFrames, Track(neutralMetadata, "head"), profile.neutralTime),
                Sample(neutralFrames, Track(neutralMetadata, "L-hand"), profile.neutralTime),
                Sample(neutralFrames, Track(neutralMetadata, "R-hand"), profile.neutralTime) };
            _frames = frames; _metadata = metadata; _profile = profile; _neutral = neutral;
            _head = head; _left = left; _right = right;
            _start = Mathf.Clamp(profile.startTime, (float)frames[0].time, (float)frames[frames.Count-1].time - 0.01f);
            _end = profile.endTime > _start ? Mathf.Min(profile.endTime, (float)frames[frames.Count-1].time)
                : (float)frames[frames.Count-1].time;
            EstimateGait();
            PlaybackTime = 0; CurrentMotion = metadata.sessionName; IsPlaying = true;
            PrepareGraph();
            if (useBaseAnimation && baseAnimatorController != null && animator.HasState(0, Animator.StringToHash(CurrentMotion)))
                animator.Play(CurrentMotion, 0, 0);
            ApplyPose(0); return true;
        }

        public void Pause() { IsPlaying = false; if (animator != null) animator.speed = 0; }
        public void Resume() { if (_frames != null) IsPlaying = true; }
        public void Seek(float seconds)
        {
            if (_frames == null) return;
            if (_lastBaseAnimation != useBaseAnimation) PrepareGraph();
            PlaybackTime = Mathf.Clamp(seconds, 0, Duration); ApplyPose(0);
        }
        public void Stop()
        {
            IsPlaying = false; _frames = null; PlaybackTime = 0; CurrentMotion = "";
            if (animator != null) animator.speed = 0;
            RestoreBones();
            foreach (var r in rotations) r.control.rotation = transform.rotation * r.restInRoot;
            pelvisPositionControl.position = transform.TransformPoint(_pelvisRest);
            foreach (var l in legs)
            {
                l.target.SetPositionAndRotation(transform.TransformPoint(l.restPosition), transform.rotation * l.restRotation);
                l.hint.position = transform.TransformPoint(l.hintPosition);
            }
            if (rigBuilder.graph.IsValid()) rigBuilder.Evaluate(0);
        }

        private void RestoreBones()
        {
            if (_bones == null) return;
            for (int i=0; i<_bones.Length; i++)
                _bones[i].SetLocalPositionAndRotation(_positions[i], _rotations[i]);
        }

        private void ApplyPose(float deltaTime)
        {
            if (!useBaseAnimation) RestoreBones();
            var head = Read(_head); var left = Read(_left); var right = Read(_right);
            Quaternion basis = Quaternion.Euler(sourceToSheepEuler);
            Quaternion rotation = basis * (head.rotation * Quaternion.Inverse(_neutral[0].rotation)) * Quaternion.Inverse(basis);
            // Quaternion logarithm keeps a large nod from becoming an Euler yaw/roll flip.
            rotation.ToAngleAxis(out float angle, out Vector3 axis);
            if (angle > 180) angle -= 360;
            Vector3 raw = Mathf.Abs(angle) < 0.001f ? Vector3.zero : axis * angle;
            for (int i=0; i<3; i++) raw[i] = Mathf.Clamp(raw[i] * _profile.rotationGain[i], -_profile.angleLimits[i], _profile.angleLimits[i]);
            float alpha = deltaTime <= 0 || _profile.smoothingSeconds <= 0 ? 1 : 1-Mathf.Exp(-deltaTime/_profile.smoothingSeconds);
            _filteredAngles = Vector3.Lerp(_filteredAngles, raw, alpha);
            bool walking = _profile.expression == SheepExpression.Walk;
            float phase = PlaybackTime * _frequency * Mathf.PI * 2;
            float legLength = legs[0].length;
            float drop = Mathf.Max(0, _neutral[0].position.y-head.position.y);
            float crouch = _profile.expression == SheepExpression.Eat ? Mathf.Clamp01(drop/0.65f) : 0;
            Vector3 bodyAngles = _filteredAngles * _profile.bodyFollow;
            bodyAngles.x += crouch * 12;
            if (walking) bodyAngles.z += Mathf.Sin(phase)*4;
            bodyAngles.x = Mathf.Clamp(bodyAngles.x, -18, 18);
            bodyAngles.y = Mathf.Clamp(bodyAngles.y, -12, 12);
            bodyAngles.z = Mathf.Clamp(bodyAngles.z, -10, 10);
            Vector3 bodyOffset = Vector3.up * (walking ? Mathf.Cos(phase*2)*legLength*_profile.bounceFraction : 0);
            bodyOffset += Vector3.down * (crouch*legLength*_profile.crouchFraction);
            pelvisPositionControl.position = transform.TransformPoint(_pelvisRest+bodyOffset);
            _desiredRotations.Clear();
            foreach(var binding in rotations)
            {
                Quaternion body = Quaternion.Euler(bodyAngles * binding.bodyShare);
                float share = binding.finalHead ? 1 : binding.headShare * _profile.neckShare;
                Quaternion headPart = _filteredAngles.sqrMagnitude < 0.0001f ? Quaternion.identity
                    : Quaternion.AngleAxis(_filteredAngles.magnitude * share, _filteredAngles.normalized);
                binding.control.rotation = transform.rotation * body * headPart * binding.restInRoot;
                _desiredRotations[binding.bone] = binding.control.rotation;
            }
            Vector3 handLeft = basis*(left.position-_neutral[1].position);
            Vector3 handRight = basis*(right.position-_neutral[2].position);
            foreach(var leg in legs)
            {
                Vector3 targetLocal = leg.restPosition;
                if (walking)
                {
                    // Diagonal pairs are phase-opposed. Stance follows an in-place treadmill path.
                    float legPhase = phase + (leg.left == leg.front ? 0 : Mathf.PI);
                    targetLocal.z += Mathf.Cos(legPhase)*leg.length*_profile.strideFraction;
                    targetLocal.y += Mathf.Max(0, Mathf.Sin(legPhase))*leg.length*_profile.liftFraction;
                    Vector3 hand = leg.left ? handLeft : handRight;
                    targetLocal.z += Mathf.Clamp(hand.z*_profile.handInfluence,-leg.length*0.08f,leg.length*0.08f);
                }
                Vector3 hipWorld = PredictPosition(leg.hip);
                Vector3 world = transform.TransformPoint(targetLocal);
                float worldLength = leg.length * Mathf.Abs(transform.lossyScale.y);
                world = hipWorld + Vector3.ClampMagnitude(world-hipWorld,worldLength*0.98f);
                leg.target.SetPositionAndRotation(world,transform.rotation*leg.restRotation);
                leg.hint.position = transform.TransformPoint(leg.hintPosition+bodyOffset);
            }
            rigBuilder.Evaluate(0);
        }

        private Vector3 PredictPosition(Transform bone)
        {
            if (bone == pelvis) return pelvisPositionControl.position;
            if (!_boneIndices.TryGetValue(bone,out int index)) return bone.position;
            return PredictPosition(bone.parent) + PredictRotation(bone.parent) * Vector3.Scale(_positions[index], bone.parent.lossyScale);
        }
        private Quaternion PredictRotation(Transform bone)
        {
            if (_desiredRotations.TryGetValue(bone,out var desired)) return desired;
            if (!_boneIndices.TryGetValue(bone,out int index)) return bone.rotation;
            return PredictRotation(bone.parent)*_rotations[index];
        }

        private RecordedTransformSample Read(int track)
        {
            var current = Sample(_frames,track,_start+PlaybackTime);
            float blendTime = Mathf.Min(_profile.loopBlendSeconds,Duration*0.25f);
            if (loop && blendTime>0 && PlaybackTime>Duration-blendTime)
                current = Blend(current,Sample(_frames,track,_start),Mathf.SmoothStep(0,1,(PlaybackTime-Duration+blendTime)/blendTime));
            return current;
        }

        private void EstimateGait()
        {
            _frequency = _profile.fallbackCyclesPerSecond; GaitSource = "not a gait motion";
            if (_profile.expression != SheepExpression.Walk) return;
            GaitSource = "profile fallback";
            var crossings=new List<float>();
            float min=float.MaxValue,max=float.MinValue;
            foreach(var f in _frames) if(f.time>=_start && f.time<=_end)
            { float value=f.samples[_left].position.z-f.samples[_right].position.z; min=Mathf.Min(min,value);max=Mathf.Max(max,value); }
            if(max-min<0.025f) return;
            float centre=(min+max)*0.5f,previous=0,lastCross=-10;
            bool armed=false;
            foreach(var f in _frames) if(f.time>=_start && f.time<=_end)
            {
                float value=f.samples[_left].position.z-f.samples[_right].position.z-centre;
                if(value<-(max-min)*0.1f) armed=true;
                if(armed && previous<=0 && value>0 && f.time-lastCross>0.3)
                {lastCross=(float)f.time;crossings.Add(lastCross);armed=false;}
                previous=value;
            }
            if(crossings.Count<3) return;
            var intervals=new List<float>();
            for(int i=1;i<crossings.Count;i++) intervals.Add(crossings[i]-crossings[i-1]);
            intervals.Sort(); float period=intervals[intervals.Count/2];
            _frequency=Mathf.Clamp(1/period,0.3f,2f);
            // Integer cycles yield a continuous gait at the loop boundary.
            if(loop) _frequency=Mathf.Max(1,Mathf.Round(Duration*_frequency))/Duration;
            GaitSource="recorded hand crossing rhythm";
        }

        private static int Track(TransformMotionMetadata metadata,string id)
        {
            for(int i=0;i<metadata.tracks.Length;i++) if(metadata.tracks[i].id==id)
            {
                var t=metadata.tracks[i];
                if(!t.recordsPosition || !t.recordsRotation || t.coordinateSpace!="relativeToReference")
                    throw new InvalidOperationException("V1 expects TrackingSpace-relative position and rotation: "+id);
                return i;
            }
            throw new InvalidOperationException("Missing track: "+id);
        }
        private static RecordedTransformSample Sample(List<TransformMotionFrame> frames,int track,float time)
        {
            int low=0,high=frames.Count-1;
            while(low<high){int mid=(low+high)/2;if(frames[mid].time<time)low=mid+1;else high=mid;}
            var a=frames[Mathf.Max(0,low-1)];var b=frames[low];
            float amount=b.time>a.time ? Mathf.Clamp01((time-(float)a.time)/(float)(b.time-a.time)):0;
            return Blend(a.samples[track],b.samples[track],amount);
        }
        private static RecordedTransformSample Blend(RecordedTransformSample a,RecordedTransformSample b,float t)
        {
            return new RecordedTransformSample {position=Vector3.Lerp(a.position,b.position,t),rotation=Quaternion.Slerp(a.rotation,b.rotation,t),activeInHierarchy=a.activeInHierarchy&&b.activeInHierarchy};
        }
    }
}
