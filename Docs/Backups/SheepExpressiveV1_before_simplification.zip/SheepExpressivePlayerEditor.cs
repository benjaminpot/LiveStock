using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace LiveStock.MotionRecording.Editor
{
    [CustomEditor(typeof(SheepExpressivePlayer))]
    public sealed class SheepExpressivePlayerEditor : UnityEditor.Editor
    {
        public override VisualElement CreateInspectorGUI()
        {
            var root=new VisualElement();
            var player=(SheepExpressivePlayer)target;
            root.Add(new HelpBox("V1: Head/neck rotation + body expression + four-foot IK. Default is pure procedural playback. Walk hind legs are generated from recorded hand rhythm.",HelpBoxMessageType.Info));
            var settings=new VisualElement();InspectorElement.FillDefaultInspector(settings,serializedObject,this);
            root.Add(settings);
            var controls=new VisualElement();
            foreach(string name in new[]{"idle","eat","walk"})
            {string motion=name;controls.Add(new Button(()=>player.Play(motion)){text="Play "+motion});}
            controls.Add(new Button(()=>player.PlayCustom()){text="Play Dragged Recording"});
            controls.Add(new Button(player.Pause){text="Pause"});
            controls.Add(new Button(player.Resume){text="Resume"});
            controls.Add(new Button(player.Stop){text="Stop / Restore"});
            var seek=new Slider("Time (seconds)",0,1);
            seek.RegisterValueChangedCallback(e=>{player.Pause();player.Seek(e.newValue);});
            controls.Add(seek);var status=new Label();controls.Add(status);root.Add(controls);
            root.schedule.Execute(()=>
            {
                if(player==null) return;
                controls.SetEnabled(Application.isPlaying);
                seek.highValue=Mathf.Max(0.01f,player.Duration);
                seek.SetValueWithoutNotify(player.PlaybackTime);
                status.text=player.CurrentMotion+" | "+player.PlaybackTime.ToString("F2")+"s | "+player.GaitFrequency.ToString("F2")+" cycles/s | "+player.GaitSource;
            }).Every(100);
            return root;
        }
    }
}
