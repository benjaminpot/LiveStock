using UnityEngine;

namespace LiveStock.MotionRecording
{
    public enum SheepExpression { Idle, Eat, Walk }

    [CreateAssetMenu(menuName = "LiveStock/Expressive Sheep Profile")]
    public sealed class SheepExpressiveProfile : ScriptableObject
    {
        public SheepExpression expression;
        [Tooltip("Seconds in the neutral recording used for calibration; independent of this motion's first frame.")]
        [Min(0)] public float neutralTime;
        [Min(0)] public float startTime;
        [Tooltip("0 uses the full recording.")]
        [Min(0)] public float endTime;
        [Min(0)] public float loopBlendSeconds = 0.25f;
        public Vector3 rotationGain = new Vector3(1.5f, 1.5f, 1.6f);
        public Vector3 angleLimits = new Vector3(85f, 65f, 40f);
        [Range(0, 1)] public float neckShare = 0.4f;
        [Range(0, 1)] public float bodyFollow = 0.12f;
        [Range(0, 0.25f)] public float crouchFraction = 0.06f;
        [Range(0, 0.3f)] public float strideFraction = 0.17f;
        [Range(0, 0.4f)] public float liftFraction = 0.2f;
        [Range(0, 0.12f)] public float bounceFraction = 0.025f;
        [Range(0, 1)] public float handInfluence = 0.35f;
        [Min(0.01f)] public float fallbackCyclesPerSecond = 0.8f;
        [Min(0)] public float smoothingSeconds = 0.07f;
    }
}
