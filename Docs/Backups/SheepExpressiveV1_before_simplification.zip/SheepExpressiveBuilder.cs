using System;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Animations.Rigging;

namespace LiveStock.MotionRecording.Editor
{
    public static class SheepExpressiveBuilder
    {
        public const string PrefabPath = "Assets/_Project/model/SK_Sheep_ExpressiveV1.prefab";
        private const string ProfileFolder = "Assets/_Project/Generated/SheepExpressiveV1";

        [MenuItem("Tools/LiveStock/Create Expressive Sheep V1")]
        public static void Build()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("Create the V1 prefab in Edit Mode.");
            Folder(ProfileFolder);
            var root=PrefabUtility.LoadPrefabContents("Assets/_Project/model/SK_Sheep_white.prefab");
            try
            {
                root.name="SK_Sheep_ExpressiveV1";
                root.transform.SetPositionAndRotation(Vector3.zero,Quaternion.identity);
                root.transform.localScale=Vector3.one;
                var oldBuilder=root.GetComponent<RigBuilder>();
                if(oldBuilder!=null) UnityEngine.Object.DestroyImmediate(oldBuilder);
                foreach(var oldRig in root.GetComponentsInChildren<Rig>(true)) UnityEngine.Object.DestroyImmediate(oldRig.gameObject);
                foreach(var c in root.GetComponents<MonoBehaviour>())
                    if(c!=null && c.GetType().FullName=="Ursaanimation.CubicFarmAnimals.AnimationController") c.enabled=false;
                var animator=root.GetComponent<Animator>();
                animator.runtimeAnimatorController=null;
                animator.applyRootMotion=false;
                animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
                var builder=root.AddComponent<RigBuilder>();
                var controls=Child(root.transform,"ExpressionControls");
                var body=Layer(root.transform,"V1_Body",builder);
                var head=Layer(root.transform,"V1_HeadNeck",builder);
                var legs=Layer(root.transform,"V1_FourLegs",builder);
                var player=root.AddComponent<SheepExpressivePlayer>();
                player.animator=animator;player.rigBuilder=builder;
                player.neutralPoseClip=CreateNeutralPose(root);
                player.baseAnimatorController=AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>("Assets/_Project/Generated/MotionPlayback/SheepVrMotion.controller");
                player.pelvis=Bone(root,"Pelvis_joint");
                player.pelvisPositionControl=Child(controls,"PelvisPosition");
                player.pelvisPositionControl.position=player.pelvis.position;
                var position=Child(body,"PelvisPositionConstraint").gameObject.AddComponent<MultiPositionConstraint>();
                var pd=position.data;pd.constrainedObject=player.pelvis;
                var sources=new WeightedTransformArray();sources.Add(new WeightedTransform(player.pelvisPositionControl,1));
                pd.sourceObjects=sources;pd.maintainOffset=false;position.data=pd;position.weight=1;
                string[] names={"Pelvis_joint","Spine1_M_joint","Spine2_M_joint","Neck_M_joint","Neck1_M_joint","Head_M_joint"};
                float[] shares={0,0,0,0.5f,1,1};
                var bindings=new List<SheepRotationControl>();
                for(int i=0;i<names.Length;i++)
                {
                    var bone=Bone(root,names[i]);var control=Child(controls,names[i]+"_Orientation");
                    control.SetPositionAndRotation(bone.position,bone.rotation);
                    var constraint=Child(i<3?body:head,names[i]+"_Rotation").gameObject.AddComponent<MultiRotationConstraint>();
                    var data=constraint.data;data.constrainedObject=bone;data.maintainOffset=false;
                    var input=new WeightedTransformArray();input.Add(new WeightedTransform(control,1));
                    data.sourceObjects=input;constraint.data=data;constraint.weight=1;
                    bindings.Add(new SheepRotationControl{bone=bone,control=control,headShare=shares[i],finalHead=i==5,bodyShare=i==0?0.4f:i==1?0.7f:1,restInRoot=Quaternion.Inverse(root.transform.rotation)*bone.rotation});
                }
                player.rotations=bindings.ToArray();
                var footBindings=new List<SheepLegControl>();
                foreach(bool front in new[]{true,false}) foreach(bool left in new[]{true,false})
                {
                    string suffix=(front?"Front":"")+"_"+(left?"L":"R")+"_joint";
                    var hip=Bone(root,"Hip"+suffix);var knee=Bone(root,"Knee"+suffix);var ankle=Bone(root,"Ankle"+suffix);
                    if(knee.parent!=hip || ankle.parent!=knee) throw new InvalidOperationException("V1 leg is not a direct two-bone chain: "+suffix);
                    var target=Child(controls,(front?"Front":"Hind")+(left?"Left":"Right")+"Foot");
                    target.SetPositionAndRotation(ankle.position,ankle.rotation);
                    var hint=Child(controls,target.name+"Hint");
                    float length=Vector3.Distance(hip.position,knee.position)+Vector3.Distance(knee.position,ankle.position);
                    Vector3 mid=(hip.position+ankle.position)*0.5f;
                    Vector3 bend=knee.position-mid;
                    if(bend.magnitude<length*0.05f) bend=root.transform.forward*(front?-1:1);
                    hint.position=knee.position+bend.normalized*length*0.6f;
                    // Avoid the antiparallel pole singularity on this almost-straight leg model.
                    hint.position+=root.transform.right*(left?-1:1)*length*0.3f;
                    var ik=Child(legs,target.name+"IK").gameObject.AddComponent<TwoBoneIKConstraint>();
                    var d=ik.data;d.root=hip;d.mid=knee;d.tip=ankle;d.target=target;d.hint=hint;
                    d.targetPositionWeight=1;d.targetRotationWeight=1;d.hintWeight=1;
                    d.maintainTargetPositionOffset=false;d.maintainTargetRotationOffset=false;
                    ik.data=d;ik.weight=1;
                    footBindings.Add(new SheepLegControl{hip=hip,knee=knee,ankle=ankle,target=target,hint=hint,length=length,front=front,left=left,restPosition=root.transform.InverseTransformPoint(ankle.position),restRotation=Quaternion.Inverse(root.transform.rotation)*ankle.rotation,hintPosition=root.transform.InverseTransformPoint(hint.position)});
                }
                player.legs=footBindings.ToArray();
                var idle=Recording("Idle");var eat=Recording("Eat");var walk=Recording("Walk");
                player.neutralRecording=idle;
                player.motions=new[]{
                    new SheepExpressiveMotion{name="idle",recording=idle,profile=Profile("Idle",SheepExpression.Idle)},
                    new SheepExpressiveMotion{name="eat",recording=eat,profile=Profile("Eat",SheepExpression.Eat)},
                    new SheepExpressiveMotion{name="walk",recording=walk,profile=Profile("Walk",SheepExpression.Walk)} };
                player.defaultMotion="idle";player.playOnStart=true;
                player.customRecording=walk;player.customProfile=player.motions[2].profile;
                PrefabUtility.SaveAsPrefabAsset(root,PrefabPath);
            }
            finally{PrefabUtility.UnloadPrefabContents(root);}
            AssetDatabase.SaveAssets();
            Debug.Log("Created independent expressive V1 sheep: "+PrefabPath);
        }

        [MenuItem("Tools/LiveStock/Add Expressive Sheep V1 To Scene")]
        public static void AddToScene()
        {
            var scene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            if(scene.GetRootGameObjects().Any(x=>x.name=="SK_Sheep_ExpressiveV1"))
                throw new InvalidOperationException("A V1 comparison sheep already exists in this scene.");
            var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            if(prefab==null) throw new InvalidOperationException("Create V1 prefab first.");
            var instance=(GameObject)PrefabUtility.InstantiatePrefab(prefab,scene);
            Undo.RegisterCreatedObjectUndo(instance,"Add expressive V1 sheep");
            var reference=scene.GetRootGameObjects().FirstOrDefault(x=>x.name=="SK_Sheep_VRMotion");
            if(reference==null) reference=scene.GetRootGameObjects().FirstOrDefault(x=>x.name=="SK_Sheep_white");
            if(reference!=null)
            {
                instance.transform.SetPositionAndRotation(reference.transform.position+reference.transform.right*1.5f,reference.transform.rotation);
                instance.transform.localScale=reference.transform.localScale;
            }
            EditorSceneManager.MarkSceneDirty(scene);Selection.activeGameObject=instance;
        }
        private static SheepExpressiveProfile Profile(string name,SheepExpression expression)
        {
            string path=ProfileFolder+"/"+name+".asset";
            var p=AssetDatabase.LoadAssetAtPath<SheepExpressiveProfile>(path);
            if(p!=null) return p;
            p=ScriptableObject.CreateInstance<SheepExpressiveProfile>();p.expression=expression;
            if(expression==SheepExpression.Eat){p.bodyFollow=0.22f;p.rotationGain=new Vector3(1.35f,1.4f,1.5f);p.crouchFraction=0.12f;}
            if(expression==SheepExpression.Walk){p.bodyFollow=0.08f;p.rotationGain=new Vector3(1.4f,1.4f,1.7f);}
            AssetDatabase.CreateAsset(p,path);return p;
        }
        private static AnimationClip CreateNeutralPose(GameObject root)
        {
            string path=ProfileFolder+"/NeutralPose.anim";
            var clip=AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
            if(clip==null){clip=new AnimationClip{name="V1 Neutral Pose",frameRate=30};AssetDatabase.CreateAsset(clip,path);}
            foreach(var bone in Bone(root,"Base_joint").GetComponentsInChildren<Transform>(true))
            {
                string bonePath=AnimationUtility.CalculateTransformPath(bone,root.transform);
                Vector3 pos=bone.localPosition,scale=bone.localScale;Quaternion rotation=bone.localRotation;
                string[] properties={"m_LocalPosition.x","m_LocalPosition.y","m_LocalPosition.z","m_LocalRotation.x","m_LocalRotation.y","m_LocalRotation.z","m_LocalRotation.w","m_LocalScale.x","m_LocalScale.y","m_LocalScale.z"};
                float[] values={pos.x,pos.y,pos.z,rotation.x,rotation.y,rotation.z,rotation.w,scale.x,scale.y,scale.z};
                for(int i=0;i<properties.Length;i++)AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve(bonePath,typeof(Transform),properties[i]),AnimationCurve.Constant(0,1,values[i]));
            }
            clip.EnsureQuaternionContinuity();EditorUtility.SetDirty(clip);return clip;
        }
        private static MotionRecordingAsset Recording(string name)
        {
            var result=AssetDatabase.LoadAssetAtPath<MotionRecordingAsset>("Assets/MotionRecordings/Library/"+name+".asset");
            if(result==null) throw new InvalidOperationException("Missing recording: "+name);return result;
        }
        private static Transform Bone(GameObject root,string name)
        {
            var result=root.GetComponentsInChildren<Transform>(true).FirstOrDefault(t=>t.name==name);
            if(result==null) throw new InvalidOperationException("Missing bone: "+name);return result;
        }
        private static Transform Child(Transform parent,string name)
        {var t=new GameObject(name).transform;t.SetParent(parent,false);return t;}
        private static Transform Layer(Transform root,string name,RigBuilder builder)
        {var t=Child(root,name);var rig=t.gameObject.AddComponent<Rig>();builder.layers.Add(new RigLayer(rig));return t;}
        private static void Folder(string path)
        {
            string current="Assets";foreach(var part in path.Split('/').Skip(1)){string next=current+"/"+part;if(!AssetDatabase.IsValidFolder(next))AssetDatabase.CreateFolder(current,part);current=next;}
        }
    }
}
